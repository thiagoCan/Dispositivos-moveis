package br.com.areatecbrasil.androidfirebaseproject;

public class Ponto {
    private Double latitude;
    private Double longitude;
    private Double altitude;

    Ponto() {
        this.latitude  = 0.0;
        this.longitude = 0.0;
        this.altitude  = 0.0;
    }

    Ponto(Double latitude, Double longitude) {
        this();
        this.latitude  = latitude;
        this.longitude = longitude;
    }

    Ponto(Double latitude, Double longitude, Double altitude) {
        this(latitude, longitude);
        this.altitude = altitude;
    }

    public Double getLatitude() {return latitude;}

    public Double getLongitude() {return longitude;}

    public Double getAltitude() {return altitude;}

    public void setLatitude(Double latitude) {this.latitude = latitude;}

    public void setLongitude(Double longitude) {this.longitude = longitude;}

    public void setAltitude(Double altitude) {this.altitude = altitude;}

    @Override
    public String toString() {
        return " latitude: "    + latitude +
                "\n longitude: " + longitude;
        // + "\n altitude: "  + altitude;
    }
}
