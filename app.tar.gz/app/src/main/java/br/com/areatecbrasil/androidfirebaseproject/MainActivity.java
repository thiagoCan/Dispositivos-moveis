package br.com.areatecbrasil.androidfirebaseproject;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.DecimalFormat;
import android.icu.text.SimpleDateFormat;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Date;
import java.util.Locale;
import java.util.Random;

import br.com.areatecbrasil.androidfirebaseproject.Activity.Login;
import br.com.areatecbrasil.androidfirebaseproject.model.DataModel;

public class MainActivity extends AppCompatActivity {
    private Ponto p1, p2;
    private String PROVIDER;
    private FirebaseAuth mAuth;
    protected static Random random = new Random();
    // private Object Date;

    private FusedLocationProviderClient mFusedLocationClient;
    //
    // posicao inicial: FATEC
    //
    private double iniLatitude = -23.1621736, iniLongitude = -45.7959114, wayLatitude = 0.0, wayLongitude = 0.0;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    // private android.widget.Button btnLocation;
    private TextView txtLocation;
    private TextView txtContinueLocation;
    private StringBuilder stringBuilder;

    private boolean isContinue = false;
    private boolean isGPS = false;
    private boolean isResetedP1 = false;
    private boolean isResetedP2 = false;
    private Ponto location;
    private Ponto localAtual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        PROVIDER = LocationManager.GPS_PROVIDER;

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10 * 1000); // 10 seconds
        locationRequest.setFastestInterval(5 * 1000); // 5 seconds

        new GpsUtils(this).turnGPSOn(new GpsUtils.onGpsListener() {
            @Override
            public void gpsStatus(boolean isGPSEnable) {
                // turn on GPS
                isGPS = isGPSEnable;
            }
        });

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {

                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        wayLatitude = location.getLatitude();
                        wayLongitude = location.getLongitude();
                        if (!isContinue) {
                            txtLocation.setText(String.format(Locale.US, "%s - %s", wayLatitude, wayLongitude));
                            ((EditText)findViewById(R.id.edtPonto1)).setText(txtLocation.toString());
                        } else {
                            stringBuilder.append(wayLatitude);
                            stringBuilder.append("-");
                            stringBuilder.append(wayLongitude);
                            stringBuilder.append("\n\n");
                            txtContinueLocation.setText(stringBuilder.toString());
                            //
                        }
                        if (!isContinue && mFusedLocationClient != null) {
                            mFusedLocationClient.removeLocationUpdates(locationCallback);
                        }
                    }
                }
            }
        };
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentuser;
        currentuser = FirebaseAuth.getInstance().getCurrentUser();

        isResetedP1 = true;
        isResetedP2 = true;

        if (currentuser == null) {
            Intent intent = new Intent(MainActivity.this, Login.class);
            startActivity(intent);
            finish();
        }
        //
    }

    @Override
    protected void onStop() {
        super.onStop();
        FirebaseAuth.getInstance().signOut();
        finish();
    }

    private void zerarPontos() {
        p1 = new Ponto();
        p2 = new Ponto();
    }

    public void reset(View v) {
        //
        isContinue = false;
        //
        zerarPontos();
        //
        if (!isGPS) {
            Toast.makeText(this, "Ligue o GPS do celular", Toast.LENGTH_SHORT).show();
            return;
        }
        //
        p1.setLatitude(iniLatitude); // ini
        p1.setLongitude(iniLongitude); // ini
        //
        Toast.makeText(MainActivity.this, ""+p1.toString(), Toast.LENGTH_LONG).show();
        //
        p2.setLatitude(p1.getLatitude());
        p2.setLongitude(p1.getLongitude());
        //
        isResetedP2 =true;
        //
        if (isResetedP1 == true){
            try{
                //
                mostrarGoogleMaps(p1.getLatitude(), p1.getLongitude());
                //
            }
            catch (Exception ex)
            {
            }
            isResetedP1 =false;
        }
        //
    }

    public void lerPonto1(View v) {
        p1 = new Ponto();

        String latLng = getPointFromGoogleMaps();
        if(latLng.length() > 0){
            String lat = latLng.split(",")[0];
            String lng = latLng.split(",")[1];
            p1.setLatitude(Double.parseDouble(lat));
            p1.setLongitude(Double.parseDouble(lng));
            p1.setAltitude(0.0);
        }

        ((EditText)findViewById(R.id.edtPonto1)).setText(p1.toString());

        isResetedP2 =true;

    }

    public void lerPonto2(View v) {
        p2 = new Ponto();

        String latLng = getPointFromGoogleMaps();
        if(latLng.length() > 0){
            String lat = latLng.split(",")[0];
            String lng = latLng.split(",")[1];
            p2.setLatitude(Double.parseDouble(lat));
            p2.setLongitude(Double.parseDouble(lng));
            p2.setAltitude(0.0);
        }

        ((EditText)findViewById(R.id.edtPonto2)).setText(p2.toString());

        isResetedP2 =false;

    }

    public Ponto getPonto() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)   != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            return null;
        }

        LocationManager mLocManager  = (LocationManager) getSystemService(MainActivity.this.LOCATION_SERVICE);
        LocationListener mLocListener = new MinhaLocalizacaoListener();

        mLocManager.requestLocationUpdates(PROVIDER, 0, 0, mLocListener);

        Location localAtual = mLocManager.getLastKnownLocation(PROVIDER);

        if (! mLocManager.isProviderEnabled(PROVIDER)) {
            Toast.makeText(MainActivity.this, "GPS Desabilitado.", Toast.LENGTH_LONG).show();
        }

        //return new Ponto(localAtual.getLatitude, localAtual.getLongitude, localAtual.getAltitude);
        return new Ponto(MinhaLocalizacaoListener.latitude,
                MinhaLocalizacaoListener.longitude,
                MinhaLocalizacaoListener.altitude);
    }

    public void verPonto1(View v) {
        try{
            if(p1.getLatitude()==null) { p1.setLatitude(iniLatitude); }
            if(p1.getLongitude()==null) { p1.setLongitude(iniLongitude); }

            mostrarGoogleMaps(p1.getLatitude(), p1.getLongitude());
        }
        catch (Exception ex)
        {
        }
    }

    public void verPonto2(View v) {
        if(isResetedP2 ==false){
            try{
                if(p2.getLatitude()==null) { p2.setLatitude(p1.getLatitude()); }
                if(p2.getLongitude()==null) { p2.setLongitude(p1.getLongitude()); }

                mostrarGoogleMaps(p2.getLatitude(), p2.getLongitude());
            }
            catch (Exception ex)
            {
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    public void mostrarGoogleMaps(double latitude, double longitude) {
        WebView wv = findViewById(R.id.webv);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.loadUrl("https://www.google.com/maps/search/?api=1&query=" + latitude + "," + longitude);

    }
    @SuppressLint("SetJavaScriptEnabled")
    public String getPointFromGoogleMaps(){
        try{

            WebView wv = findViewById(R.id.webv);
            wv.getSettings().setJavaScriptEnabled(true);
             String url = wv.getUrl();
              url = url.split("@")[1];
             String latLng = url.split(",")[0];
             latLng += ", " + url.split(",")[1];
             return latLng;
        }
        catch (Exception ex)
        {
            return "";
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void calcularDistancia(View v) {
        //LocationManager mLocManager  = (LocationManager) getSystemService(MainActivity.this.LOCATION_SERVICE);
        float[] resultado = new float[1];
        //
        /*
        double LatMin = randomInRange( -23.164195, -23.252862);
        double LatMax = randomInRange( -23.164195, -23.252862);
        double LonMin = randomInRange( -45.790585, -45.912293);
        double LonMax = randomInRange( -45.790585, -45.912293);
        */
        //
        double LatMin = p1.getLatitude();
        double LatMax = p2.getLatitude();
        double LonMin = p1.getLongitude();
        double LonMax = p2.getLongitude();

        String hora;
        String data;
        float Distancia; // = new Float[1];

        // Location.distanceBetween(p1.getLatitude(), p1.getLongitude(), p2.getLatitude(), p2.getLongitude(), resultado);

        Location.distanceBetween(LatMin, LonMin, LatMax, LonMax, resultado);

        Distancia= resultado[0];

        DecimalFormat var = new DecimalFormat("#.##");

        Toast.makeText(MainActivity.this,"Distância: "+var.format(resultado[0]) + " metros",Toast.LENGTH_SHORT).show();

        DataModel datamodel =  new DataModel();

        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        datamodel.setHora(currentTime);
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        datamodel.setData(currentDate);

        datamodel.setId(mAuth.getUid()+" "+currentDate+" "+currentTime);
        datamodel.setP1Lat( (float) LatMin);
        datamodel.setP1Lon( (float) LonMin);
        datamodel.setP2Lat( (float) LatMax);
        datamodel.setP2Lon( (float) LonMax);

        datamodel.setDistancia((float ) Distancia);

        datamodel.Salvar();

    }

    public static double randomInRange(double min, double max) {
        double range = max - min;
        double scaled = random.nextFloat() * range;
        double shifted = scaled + min;
        return shifted; // == (rand.nextFloat() * (max-min)) + min;
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    com.coders.location.AppConstants.LOCATION_REQUEST);

        } else {
            if (isContinue) {
                mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
            } else {
                mFusedLocationClient.getLastLocation().addOnSuccessListener(MainActivity.this, location -> {
                    if (location != null) {
                        wayLatitude = location.getLatitude();
                        wayLongitude = location.getLongitude();
                        txtLocation.setText(String.format(Locale.US, "%s - %s", wayLatitude, wayLongitude));
                    } else {
                        mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                    }
                });
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (isContinue) {
                        mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                    } else {
                        mFusedLocationClient.getLastLocation().addOnSuccessListener(MainActivity.this, location -> {
                            if (location != null) {
                                wayLatitude = location.getLatitude();
                                wayLongitude = location.getLongitude();
                                txtLocation.setText(String.format(Locale.US, "%s - %s", wayLatitude, wayLongitude));
                            } else {
                                mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
                            }
                        });
                    }
                } else {
                    Toast.makeText(this, "Permissão negada", Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == com.coders.location.AppConstants.GPS_REQUEST) {
                isGPS = true; // flag maintain before get location
            }
        }
    }
}
