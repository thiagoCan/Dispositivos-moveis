package br.com.areatecbrasil.androidfirebaseproject.model;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

public class DataModel {
    private String id;
    private float p1Lat;
    private float p1Lon;
    private float p2Lat;
    private float p2Lon;
    private String Data;
    private String Hora;
    private float Distancia;

    public DataModel(String id, float p1Lat, float p1Lon, float p2Lat, float p2Lon, String data, String hora, float Distancia) {
        this.id = id;
        this.p1Lat = p1Lat;
        this.p1Lon = p1Lon;
        this.p2Lat = p2Lat;
        this.p2Lon = p2Lon;
        this.Data = data;
        this.Hora = hora;
        this.Distancia = Distancia;
    }

    public DataModel() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public float getP1Lat() {
        return p1Lat;
    }

    public void setP1Lat(float p1Lat) {
        this.p1Lat = p1Lat;
    }

    public float getP1Lon() {
        return p1Lon;
    }

    public void setP1Lon(float p1Lon) {
        this.p1Lon = p1Lon;
    }

    public float getP2Lat() {
        return p2Lat;
    }

    public void setP2Lat(float p2Lat) {
        this.p2Lat = p2Lat;
    }

    public float getP2Lon() {
        return p2Lon;
    }

    public void setP2Lon(float p2Lon) {
        this.p2Lon = p2Lon;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        this.Data = data;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        this.Hora = hora;
    }

    public Float getDistancia() {
        return Distancia;
    }

    public void setDistancia(float distancia) {
        this.Distancia = distancia;
    }

    public void Salvar(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("distancias").child(getId()).setValue(this);
    }
}
